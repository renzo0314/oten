from flask import Flask,render_template,request,redirect,flash
from sqlite3 import connect,Row
import sqlite3
database:str = "imageupload.db"

########################################################
def postprocess(sql:str)->bool:
    db=connect(database)
    cursor=db.cursor()
    cursor.execute(sql)
    db.commit()
    db.close()
    return True if cursor.rowcount>0 else False

def getprocess(sql:str)->list:
    db=connect(database)
    cursor=db.cursor()
    db.row_factory = Row
    cursor.execute(sql)
    data:list = cursor.fetchall()
    return data

def add_student(**kwargs)->bool:
    keys:list = list(kwargs.keys())
    values:list = list(kwargs.values())
    flds:str = "`,`".join(keys)
    vals:str = "','".join(values)
    sql:str = f"INSERT INTO `students` (`{flds}`) VALUES('{vals}')"
    return postprocess(sql)

def get_students()->list:
    sql:str = f"SELECT * FROM `students`"
    return getprocess(sql)


#########################################################

app = Flask(__name__)

uploadfolder:str = "static/images/students"
app.config['UPLOAD_FOLDER'] = uploadfolder
app.config['SECRET_KEY'] = "secretkey!@#$##$%%$"

@app.route("/saveinformation", methods=['POST'])

def saveinformation()->None:
    idno:str = request.form['idno']
    lastname:str = request.form['lastname']
    firstname:str = request.form['firstname']
    course:str = request.form['course']
    level:str = request.form['level']

    file = request.files['imageupload']
    filename = uploadfolder+"/"+file.filename
    file.save(filename)
    ok:bool = add_student(idno=idno,lastname=lastname,firstname=firstname,course=course,level=level,image=filename)
    if ok: flash("New Student Added")
    return redirect("/")

def delete_student(student_id: int) -> bool:
    sql = f"DELETE FROM `students` WHERE `id` = {student_id}"
    return postprocess(sql)
    
def update_student(student_id: int, **kwargs) -> bool:
    """ Update student's information in the database """
    updates = ", ".join([f"`{key}` = '{value}'" for key, value in kwargs.items()])
    sql = f"UPDATE `students` SET {updates} WHERE `id` = {student_id}"
    return postprocess(sql)
def get_student_by_id(student_id: int) -> Row:
    sql = f"SELECT * FROM `students` WHERE `id` = {student_id}"
    result = getprocess(sql)
    return result[0] if result else None
@app.route("/delete/<int:student_id>")
def delete(student_id: int) -> None:
    if delete_student(student_id):
        flash("Student record deleted successfully.")
    else:
        flash("Failed to delete student record.")   
    return redirect("/")

@app.route("/")
def index()->None:
    students:list = get_students()
    return render_template("index.html", students=students,pagetitle = "STUDENT REGISTRATION",)

@app.route("/edit/<int:student_id>", methods=["GET", "POST"])
def edit(student_id: int) -> None:
    student = get_student_by_id(student_id)
    
    if not student:
        flash("Student not found.")
        return redirect("/")
    
    if request.method == "POST":
        idno = request.form['idno']
        lastname = request.form['lastname']
        firstname = request.form['firstname']
        course = request.form['course']
        level = request.form['level']
   
        if 'imageupload' in request.files:
            file = request.files['imageupload']
            filename = uploadfolder + "/" + file.filename
            file.save(filename)
        else:
            filename = student['image']  
        
        # Update student 
        update_student(student_id, idno=idno, lastname=lastname, firstname=firstname, 
                       course=course, level=level, image=filename)
        
        flash("Student record updated successfully.")
        return redirect("/")

    return render_template("edit.html", student=student)

    
if __name__=="__main__":
    app.run(debug = True)
